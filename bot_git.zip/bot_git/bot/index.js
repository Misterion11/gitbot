class GitBot {
    constructor() {
        this.config = require('./config/puppeteer.json');
    }

    async init() {
        const puppeteer = require('puppeteer');
        this.browser = await puppeteer.launch({
            headless: this.config.settings.headless,
        });
        this.page = await this.browser.newPage();
        this.page.setViewport({ width: 1280, height: 720 });
    }


    async visitGithub() {
        await this.page.goto(this.config.base_url);

        await this.page.waitForTimeout(1500);

        let signBtn = await this.page.$x(this.config.selectors.sign_in);
        await signBtn[0].click();

        await this.page.waitForTimeout(500);

        await this.page.focus(this.config.selectors.username_field);
        await this.page.keyboard.type(this.config.username);

        await this.page.waitForTimeout(500);

        await this.page.focus(this.config.selectors.password_field);
        await this.page.keyboard.type(this.config.password);

        await this.page.waitForTimeout(500);

        await this.page.click(this.config.selectors.login_button);
        await this.page.waitForNavigation();

        await this.page.waitForTimeout(1500);


    }


    async visitProject() {

        let project = this.config.project
        await this.page.goto(`${this.config.base_url}/search?q=John&type=users`);

    }
    async gatherInfos(parentClass, page) {
        for (let r = 1; r < 10; r++) {

            /* #user_search_results > div.Box.border-0 > div:nth-child(${r}) > div.flex-auto > p */
            debugger;
            await page.click(`${parentClass} > div.Box.border-0 > div:nth-child(${r}) > div.flex-auto > p`)
            
            console.log('bonjour')
            await page.waitForTimeout(8000);
        }
    }



}


module.exports = GitBot